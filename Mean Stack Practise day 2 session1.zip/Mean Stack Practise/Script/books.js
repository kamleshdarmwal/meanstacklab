class books
{
	constructor(id,title,author,price)
	{
		this.id=id;
		this.title=title;
		this.author=author;
		this.price=price;
	}

	Display()
	{
		var res="Book Id:"+this.id+"<br> Name:"+this.title+"<br> Author:"+this.author+"<br> Price:"+this.price;
		var opt=document.getElementById('recdata');
		opt.innerHTML=res;
	}
}