/*function expense(id,detail,amount,date) 
{
	this.id=id;
	this.detail=detail;
	this.amount=amount;
	this.date=date;
}*/

class expense
{
	constructor(id,detail,amount,date) 
	{
			this.id=id;
			this.detail=detail;
			this.amount=amount;
			this.date=date;
	}
}